const fs = require('fs');
const chalk = require('chalk');

//new
global.botname = 'Gmzxy' //ur bot name
global.ownernumber = ['6285723400063'] //ur owner number, dont add more than one
global.ownername = 'Gmzxy' //ur owner name
global.ownername2 = '-' //ur owner name
global.websitex = ""
global.wagc = "https://whatsapp.com/channel/0029Vb1EPN53AzNXBrPUL40S"
global.saluran = "120363362254469246@newsletter"
global.jidgroupnotif = '120363362254469246@g.us'
global.saluran2 = "120363362254469246@newsletter"
global.jidgroup = '120363362254469246@g.us'
global.jidch = '120363362254469246@newsletter'
global.tiktokname = '-' //name tiktok owner
global.tiktokname2 = '-' //name tiktok2 owner
global.tiktokname3 = '-' //name tiktok3 owner
global.linkch = "https://whatsapp.com/channel/0029Vb1EPN53AzNXBrPUL40S"
global.linkgc = "https://whatsapp.com/channel/0029Vb1EPN53AzNXBrPUL40S"
global.linksosmed = "https://whatsapp.com/channel/0029Vb1EPN53AzNXBrPUL40S"
global.version = ""

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});