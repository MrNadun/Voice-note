const fs = require('node:fs')
  module.exports = {
  command: "tqto",
  alias: ["credit"],
  category: ["info"],
  description: "List Contrubutor bot ini",
  async run(m) {
    let cap = `*TERIMAKASIH KEPADA :*
Axel-Network: ( dev: sc nekobot )
Ndbotz: ( dev: scrape, sc )

My Friend
 =>  Xyroo
 =>  Ndbotz
 =>  Dafa
 =>  Verlang
 
  *[ Teman Main Mc ]*
 =>  Sulxz
 =>  Nero
 =>  Askar
 =>  xxelienx
 =>  biireal
 =>  Rusdi
 
Scrape: Ndbotz Daffa Selxyz Dll
Apikey: Rio Sanz Btch Dll
`;

await m.reply({
  document: fs.readFileSync("./image/doc.txt"),
fileName: `Thank You To`,
mimetype: 'application/msword',
jpegThumbnail:fs.readFileSync("./image/Dekusad.jpg"),
caption: cap,
contextInfo: {
      isForwarded: true,
     forwardingScore: 99999,
    forwardedNewsletterMessageInfo: {
        newsletterJid: saluran,
        serverMessageId: -1,
        newsletterName: `Tqto By: ${ownername}`,
       }
     }
    });
  },
};